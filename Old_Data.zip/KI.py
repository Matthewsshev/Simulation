import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import IsolationForest
from sklearn.inspection import DecisionBoundaryDisplay
import pandas as pd
from shapely import wkb, wkt, geometry, Point, LineString, get_coordinates, distance
from shapely.ops import transform
from pyproj import Transformer
from sklearn.ensemble import IsolationForest


def trip_length(line):
    transformer = Transformer.from_crs("epsg:4326", "epsg:3857", always_xy=True)
    # Project the LineString to the new CRS
    projected_line = transform(transformer.transform, line)
    return projected_line.length / 1000


def get_journeys(data):
    journeys = []
    journey = []
    check = data['journey'].tolist()
    prev_jr = check[0]
    cr = 0
    prev_cr = cr
    print(f'Starting the funktion to get all journeys from database')
    for jr in check:
        if cr % 5000 == 0:
            print(cr)
        if jr != prev_jr or data['name'][cr] != data['name'][prev_cr]:
            journeys.append(journey)
            journey = [cr]
        else:
            journey.append(cr)
        prev_jr = jr
        prev_cr = cr
        cr += 1
    journeys.append(journey)  # Append the last journey
    print(f'All of the journeys from database are found')
    return journeys

def convertPTtoWKT(dbname, csvname, basetime, stepjump=1, geoformat='WKT', carslist=[]):
    con = openDB(dbname)
    cur = con.cursor()
    sql_cmd = ('SELECT v.id, datetime, lat, lon, co2 '
               'FROM vehicle_data AS v '
               'ORDER BY v.id, datetime')
    if len(carslist) > 0:
        clist = '\',\''.join(carslist)
        clist = '\'' + clist + '\''
        whereclause = ' AND v.id IN (' + clist + ')'
        sql_cmd += whereclause
    res = cur.execute(sql_cmd)
    coordinate = res.fetchone()
    with open(csvname, 'w') as csvfile:
        csvfile.write(f'id,nr,startstep,starttime,endtime,wkt\n')
        stepctr = 0  # for each trip/stay (per person) the steps 1,2,3,...
        ctr = 0
        nr = 0
        stop = 0
        id_prev = coordinate[0]
        simulationstep_prev = coordinate[1]
        startsimulationstep = simulationstep_prev
        point_prev = Point(coordinate[3], coordinate[2])
        lat_prev = coordinate[3]
        stop_end = None
        coordinates = []
        while coordinate:
            ctr += 1
            stepctr += 1
            if ctr % 5000 == 0:
                print(ctr)
            id = coordinate[0]
            simulationstep = coordinate[1]
            point = Point(coordinate[3], coordinate[2])
            lat = coordinate[3]
            if lat_prev == lat and id == id_prev:
                stop += 1
            elif stop >= 600 and lat != lat_prev and id == id_prev:
                print(f'STAU')
                stop_end = True
            else:
                stop = 0
            if id != id_prev or stop_end or simulationstep - simulationstep_prev > 1 :
                nr += 1
                if stop_end:
                    if simulationstep_prev - stop != startsimulationstep:
                        trip = coordinates[:-stop]
                        wktstr = coordinates2WKT(trip, geoformat)
                        simulationstep_prev -= stop + 1
                        starttime = simulationstep2datetimestr(basetime, startsimulationstep)
                        endtime = simulationstep2datetimestr(basetime, simulationstep_prev)
                        csvstr = f'"{id_prev}","{nr}","{startsimulationstep}","{starttime}","{simulationstep_prev}","{endtime}","{wktstr}"\n'
                        csvfile.write(csvstr)
                        startsimulationstep = simulationstep_prev + 1
                        simulationstep_prev = simulationstep - 1
                        nr += 1
                    stop_end = False
                    stop = 0
                    wktstr = coordinates2WKT([point_prev], geoformat)
                else:
                    wktstr = coordinates2WKT(coordinates, geoformat)
                stepctr = 0
                starttime = simulationstep2datetimestr(basetime, startsimulationstep)
                endtime = simulationstep2datetimestr(basetime, simulationstep_prev)
                csvstr = f'"{id_prev}","{nr}","{startsimulationstep}","{starttime}","{simulationstep_prev}","{endtime}","{wktstr}"\n'
                csvfile.write(csvstr)
                coordinates = []
                coordinates.append(point)
                if stop >= 600:
                    startsimulationstep = simulationstep_prev
                else:
                    startsimulationstep = simulationstep
                if id != id_prev:
                    nr = 0
            else:
                if stepctr % stepjump == 0:
                    coordinates.append(point)
            id_prev = id
            point_prev = point
            simulationstep_prev = simulationstep_prev
            lat_prev = lat
            coordinate = res.fetchone()
        if stop >= 600:
            if simulationstep_prev - stop != startsimulationstep:
                trip = coordinates[:-stop]
                wktstr = coordinates2WKT(trip, geoformat)
                simulationstep_prev -= stop + 1
                starttime = simulationstep2datetimestr(basetime, startsimulationstep)
                endtime = simulationstep2datetimestr(basetime, simulationstep_prev)
                csvstr = f'"{id_prev}","{nr}","{startsimulationstep}","{starttime}","{simulationstep_prev}","{endtime}","{wktstr}"\n'
                csvfile.write(csvstr)
                startsimulationstep = simulationstep_prev + 1
                simulationstep_prev = simulationstep - 1
                nr += 1
            wktstr = coordinates2WKT([point_prev], geoformat)
        else:
            wktstr = coordinates2WKT(coordinates, geoformat)
        starttime = simulationstep2datetimestr(basetime, startsimulationstep)
        endtime = simulationstep2datetimestr(basetime, simulationstep_prev)
        csvstr = f'"{id_prev}","{nr}","{startsimulationstep}","{starttime}","{simulationstep_prev}","{endtime}","{wktstr}"\n'
        csvfile.write(csvstr)
    con.close()
    print(ctr)
    print('finished')



def journey_length(journeys, data):
    arr = []
    for journey in journeys:
        s = 0
        for trip in journey:
            s += data['length'][trip]
        arr.append(s)
    return arr


pd.set_option('display.max_colwidth', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
model = IsolationForest(contamination=0.05)
state = pd.read_csv('analyse/Flanderstrasse.csv')
journeys = get_journeys(state)
state['wkt'] = state['wkt'].apply(wkt.loads)
state['length'] = state['wkt'].apply(trip_length)
journey_len = journey_length(journeys, state)
X = np.array(journey_len)
X = X.reshape(-1, 1)
fit = model.fit_predict(X)
# Extract the indices where anomalies are marked as -1 (outliers)
outlier_indices = np.where(fit == -1)[0]  # Indices of the outliers
outlier_lengths = X[outlier_indices]  # Corresponding trip lengths for the outlier
# Plot trip lengths with anomalies highlighted
plt.figure(figsize=(10, 6))
plt.plot(X, label="Journey Length", color="blue")
plt.scatter(outlier_indices, outlier_lengths, color="red", label="Anomalies", marker='x')
plt.xlabel('Index')
plt.ylabel('Trip Length')
plt.title('Trip Lengths with Detected Anomalies')
plt.legend()
plt.show()
"""
n_samples, n_outliers = 120, 40
rng = np.random.RandomState(0)
covariance = np.array([[0.5, -0.1], [0.7, 0.4]])
cluster_1 = 0.4 * rng.randn(n_samples, 2) @ covariance + np.array([2, 2])  # general
cluster_2 = 0.3 * rng.randn(n_samples, 2) + np.array([-2, -2])  # spherical
outliers = rng.uniform(low=-4, high=4, size=(n_outliers, 2))

X = np.concatenate([cluster_1, cluster_2, outliers])
y = np.concatenate(
    [np.ones((2 * n_samples), dtype=int), -np.ones((n_outliers), dtype=int)]
)
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, random_state=42)
scatter = plt.scatter(X[:, 0], X[:, 1], c=y, s=20, edgecolor="k")
handles, labels = scatter.legend_elements()
plt.axis("square")
plt.legend(handles=handles, labels=["outliers", "inliers"], title="true class")
plt.title("Gaussian inliers with \nuniformly distributed outliers")
clf = IsolationForest(max_samples=100, random_state=0)
clf.fit(X_train)
disp = DecisionBoundaryDisplay.from_estimator(
    clf,
    X,
    response_method="predict",
    alpha=0.5,
)
disp.ax_.scatter(X[:, 0], X[:, 1], c=y, s=20, edgecolor="k")
disp.ax_.set_title("Binary decision boundary \nof IsolationForest")
plt.axis("square")
plt.legend(handles=handles, labels=["outliers", "inliers"], title="true class")
plt.show()"""